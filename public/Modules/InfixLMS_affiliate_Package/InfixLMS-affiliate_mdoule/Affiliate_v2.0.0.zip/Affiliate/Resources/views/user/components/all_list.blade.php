<table class="table" id="allUserTable">
    <thead>
        <tr>
            <th>{{__('common.SL')}}</th>
            <th>{{ __('common.Avatar') }}</th>
            <th>{{ __('common.Name') }}</th>
            <th>{{ __('common.Email') }}</th>
            <th>{{ __('common.Phone') }}</th>
            <th>{{ __('common.Status') }}</th>
            <th>{{ __('common.Action') }}</th>
        </tr>
    </thead>
</table>
