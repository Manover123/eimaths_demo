<div class="profile_info">
    <img class="" src="{{ getProfileImage($row->image,$row->name) }}" alt="">
</div>
