<?php

return [
    'name' => 'Affiliate'
];
